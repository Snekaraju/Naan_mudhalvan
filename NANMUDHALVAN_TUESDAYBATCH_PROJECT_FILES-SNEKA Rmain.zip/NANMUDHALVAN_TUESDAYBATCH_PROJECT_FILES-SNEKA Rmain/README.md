# NANMUDHALVAN_TUESDAYBATCH_PROJECT_FILES
# prasannaragavendran G

PROJECT CREATED BY : SNEKA R
au622021104104
paavai college of engineering



LOGIN DETAILS:


UNAME: admin


Password:admin




#Project Running steps:

python manage.py makemigrations

python manage.py migrate

python manage.py createsuperuser

python manage.py runserver
